using UnityEngine;
using System.Collections;

public class InteractableObserver : MonoBehaviour 
{
	
	private InteractableManager manager;
	
	void Awake() 
	{
		manager = GetComponent<InteractableManager>();
		manager.Register(this);
	}
	
	public void Notify(int selected, int clicked)
	{
		Debug.Log("I was notified");

		string nameSelected = manager.GetName(selected);
		string nameClicked = manager.GetName(clicked);

		if (nameSelected == "Item2" && nameClicked == "Item3" ||
			nameSelected == "Item3" && nameClicked == "Item2")
		{
			manager.SetActive(selected, false);
			manager.SetActive(clicked, false);
			int id = manager.GetId("Item4");
			manager.Set(id, new Vector3(0f, 0f, 0f), true, true, true);
		}
	}
}
