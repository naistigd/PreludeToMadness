using UnityEngine;
using System.Collections;

public class Constants 
{
	/*!
	** Offset of the selected sprite to the mouse cursor in x and y direction
	*/
	public const float MOUSE_OFFSET = 1.0f; 
	
}
