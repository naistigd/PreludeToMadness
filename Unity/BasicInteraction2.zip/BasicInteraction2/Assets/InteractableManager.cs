using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class InteractableManager : MonoBehaviour 
{	

	public Interactable[] interactables;		// an array of all our..
												// .. interactables
	private bool isInventoryOpened = false;		// record wether or not..
												// ..the inventory is open
	private int selectedInteractable = -1;		// id of the currently selected
												// interactable
	private InteractableObserver observer;		// an obsever we report to
	private List<Interactable> inventory;		// List to get the order in our
												// inventory right
	
	void Awake() 
	{
		inventory = new List<Interactable>();

		// register ourselve to each interactable object and set its id
		// which is used to reference it.
		for (int i = 0; i < interactables.Length; i++)
		{
			interactables[i].Register(this);
			interactables[i].SetId(i);

			if (interactables[i].isInInventory)
			{
				inventory.Add(interactables[i]);
			}	
		}
	}
	
	/*!
	** Sets interactable gameObjects either active or passive depending wether
	** they are in the inventory, selected, or not in the inventory and depending
	** on wether the inventar should be shown or not. 
	**
	** NOTE: (most/all) Logic in here can be delete until the state of the 
	**       class changes and does not need to be executed every frame.
	*/
	void Update()
	{
		
		if (Input.GetKeyDown(KeyCode.I))
		{
			isInventoryOpened = !isInventoryOpened;
		}
		
		if (isInventoryOpened)
		{
			UpdateInventoryOpened();
		}
		else
		{
			UpdateInventoryClosed();
		}
		
		// unselect an interactable if the right mouse button was clicked
		if (Input.GetMouseButton(1)) 
		{
      		selectedInteractable = -1;
   		}
	}
	
	/*!
	** Allow one observer to register.
	*/
	public void Register(InteractableObserver observer)
	{
		this.observer = observer;
	}
		
	/*!
	**	Called by an [Interactable] if it was left-clicked.
	*/
	public void Notify(int id)
	{
		bool isCollectable = interactables[id].isCollectable;
		bool isInInventory = interactables[id].isInInventory;
		
		if (isCollectable && !isInInventory && selectedInteractable == -1)
		{
			interactables[id].isInInventory = true;
			inventory.Add(interactables[id]);
			return;
		}

		if (isCollectable && isInInventory && selectedInteractable == -1)
		{
			selectedInteractable = id;
			return;
		}
		
		if (selectedInteractable != -1)
		{
			observer.Notify(selectedInteractable, id);
			return;
		}
	}
	
	/*!
	**	Sets the [isActive] flag in an [Interactable].
	*/
	public void SetActive(int id, bool isActive)
	{
		// if the object is to be set inactive is selected: unselect it.
		if (!isActive && id == selectedInteractable)
		{
			selectedInteractable = -1;
		}

		interactables[id].isActive = isActive;
	}
	
	/*!
	**	Sets various attributes for an [Interactable].
	*/
	public void Set(
		int id, 
		Vector3 pos, 
		bool isCollectable, 
		bool isInIventory, 
		bool isActive
	)
	{
		// if the object is to be set inactive is selected: unselect it.
		if (!isActive && id == selectedInteractable)
		{
			selectedInteractable = -1;
		}

		interactables[id].gameObject.transform.position = pos;
		interactables[id].isCollectable = isCollectable;
		interactables[id].isInInventory = isInIventory;
		interactables[id].isActive = isActive;
	}

	/*!
	** Gets the name for an [Interactable].
	*/
	public string GetName(int id)
	{
		if (id >= interactables.Length)
		{
			return "";
		}

		return interactables[id].gameObject.name;	
	}

	/*!
	** Gets the [id] for an [Interactables] name.
	*/
	public int GetId(string name)
	{
		foreach (Interactable inter in interactables)
		{
			string interName = inter.gameObject.name;

			if (interName == name)
			{
				return inter.GetId();
			}
		}

		return -1;
	}
	
	public void OpenInventory()
	{
		isInventoryOpened = true;
	}
	
	public void CloseInventory()
	{
		isInventoryOpened = false;
	}
	
	/*!
	**	Set inventory gameObjects active, and deactivate the others.
	**  And render the inventory.
	*/
	private void UpdateInventoryOpened()
	{
		// set all interactables inactive
		foreach (Interactable inter in interactables)
		{
			inter.gameObject.SetActive(false);
		}
		
		// reactivate all interactables in the [inventory]

		// TODO: Make more generic (depending on the camera settings)
		float x = -6.5f;
		float y = 4.0f;	
		float xOffset = 1.5f;

		foreach (Interactable inter in inventory)
		{
			if (inter.isActive)
			{
				// compute the position of each interactable object in the
				// inventory and set it active
				inter.gameObject.transform.position = new Vector3(
						x, y, inter.gameObject.transform.position.z
					);
				inter.gameObject.SetActive(true);
				x += xOffset;
			}
		}

		TranslateSelectedAndSetActive();
	}
	
	/*!
	**	Deactivate inventory items, activate all other items.
	*/
	private void UpdateInventoryClosed()
	{
		foreach (Interactable inter in interactables)
		{
			bool isInInventory = inter.isInInventory;
			bool isActive = inter.isActive;
			
			if (!isInInventory && isActive)
			{
				inter.gameObject.SetActive(true);	
			}
			else
			{
				inter.gameObject.SetActive(false);
			}
		}
		
		TranslateSelectedAndSetActive();
	}
	
	private void TranslateSelectedAndSetActive()
	{
		// make the selected item follow the mouse
		if (selectedInteractable != -1)
		{
			GameObject obj = interactables[selectedInteractable].gameObject;
			Vector3 pos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
			obj.SetActive(true);
			obj.transform.position = new Vector3(
					pos.x + Constants.MOUSE_OFFSET, 
					pos.y - Constants.MOUSE_OFFSET, 
					0.0f
				);
		}
	}
	
}
